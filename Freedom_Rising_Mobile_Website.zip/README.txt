FREEDOM RISING — Original 3D mobile rebuild

1. Upload index.html to a static HTTPS host (Netlify Drop or GitHub Pages).
2. Open the HTTPS address in iPhone Safari.
3. Keep an internet connection: Three.js is fetched from public CDNs.
4. The game defaults to low graphics and has touch controls.
5. If the loading screen reports an error, record its exact message.

This is the original 3D game with mobile startup improvements, not a finished photorealistic remake.
