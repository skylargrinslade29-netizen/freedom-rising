FREEDOM RISING — Animated Animals Integration
Open using a local web server or publish to Netlify; opening index.html via file:// may block glTF assets.
Assets installed: deer (animated), cow (animated), donkey (animated), chicken (textured; animation may be absent).
The deer replaces the original deer geometry once loaded. Cow and donkey appear near the settlement.
Model scale/orientation and animation names require visual testing.
Licenses are preserved in each asset folder. Confirm credits and rights before publishing.
Do not upload ZIP to GitHub; upload index.html and the assets folder.
