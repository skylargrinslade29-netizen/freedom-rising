FREEDOM RISING Update 19 — REAL CORN AND POTATO FIELDS
Based on Update 18. Adds uploaded corn and potato glTF models and textures.
Newly built fields alternate between corn and potato depending on coordinates.
Each field places 16 textured plant instances in rows and scales them according to field growth.
The original farm game logic, harvest interactions, and Update 18 animals remain.
The soil uses existing terrain textures when available.
No browser visual test has been performed. Test planting, growth, harvest and rendering after deployment.
Upload EXTRACTED files to GitHub; not the ZIP archives.
Original model license files remain in assets/crops/corn and assets/crops/potato.
